function loadTxt()
    {
    var txtLang = document.getElementsByName("txtLang");
    txtLang[0].innerHTML = "Youtube Url";
            
    document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnOk").value = " ok ";
    }
function getTxt(s)
    {
    }    
function writeTitle()
    {
    document.write("<title>Insert Youtube Video</title>")
    }