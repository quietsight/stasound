function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Are you sure you want to delete this folder?";

    document.getElementById("btnClose").value = "close";
    document.getElementById("btnDelete").value = "delete";
	}
function writeTitle()
	{
	document.write("<title>Delete Folder</title>")
	}
